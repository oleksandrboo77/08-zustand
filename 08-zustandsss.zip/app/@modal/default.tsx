export default function ModalDefault() {
  return null;
}
